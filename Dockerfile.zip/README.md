# NDVI Streamlit Application

Application for NDVI calculation using satellite data.

Formula:
NDVI = (B8 - B11) / (B8 + B11)

Technologies:
- Streamlit
- Rasterio
- GeoPandas
- Docker
