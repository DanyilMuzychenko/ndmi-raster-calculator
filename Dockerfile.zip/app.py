import streamlit as st
import rasterio
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize

import geopandas as gpd
from rasterio.features import rasterize

# ----------------------------
# Konfiguracja strony
# ----------------------------
st.set_page_config(
    page_title="NDMI – styl QGIS",
    layout="centered"
)

st.title("Normalized Difference Moisture Index (NDMI)")

st.markdown("""
**NDMI** służy do określania zawartości wody w roślinności
oraz monitorowania suszy.  
Zakres wartości: **-1 do 1**
""")

# ----------------------------
# Wzór matematyczny
# ----------------------------
st.subheader("Formuła:")
st.latex(r"NDMI = \frac{B8 - B11}{B8 + B11}")

# ----------------------------
# Wczytywanie danych
# ----------------------------
b8_file = st.file_uploader("Upload B8 (NIR)", type="tif")
b11_file = st.file_uploader("Upload B11 (SWIR)", type="tif")
area_file = st.file_uploader("Upload area (GeoJSON)", type="geojson")

if b8_file and b11_file:

    with rasterio.open(b8_file) as src:
        b8 = src.read(1).astype(np.float32)
        transform = src.transform
        raster_shape = src.shape

    with rasterio.open(b11_file) as src:
        b11 = src.read(1).astype(np.float32)

    # ----------------------------
    # Obliczanie NDMI
    # ----------------------------
    ndmi = (b8 - b11) / (b8 + b11 + 1e-6)
    ndmi = np.clip(ndmi, -0.8, 0.8)

    # ----------------------------
    # Skala kolorów w stylu QGIS
    # ----------------------------
    qgis_colors = [
        (-0.8, "#800000"),
        (-0.24, "#ff0000"),
        (-0.032, "#ffff00"),
        (0.032, "#00ffff"),
        (0.24, "#0000ff"),
        (0.8, "#000080")
    ]

    values, colors = zip(*qgis_colors)

    cmap = LinearSegmentedColormap.from_list(
        "ndmi_qgis",
        list(zip([(v + 0.8) / 1.6 for v in values], colors))
    )

    norm = Normalize(vmin=-0.8, vmax=0.8)

    # ----------------------------
    # Tytuł mapy (dynamiczny)
    # ----------------------------
    if area_file:
        st.subheader("NDMI map with selected area")
    else:
        st.subheader("NDMI map (full area)")

    fig, ax = plt.subplots(figsize=(4.5, 4.5))
    img = ax.imshow(ndmi, cmap=cmap, norm=norm)

    # ----------------------------
    # Nakładanie obszaru (jasny granatowy, pełne wypełnienie)
    # ----------------------------
    if area_file:
        gdf = gpd.read_file(area_file)

        mask_area = rasterize(
            [(geom, 1) for geom in gdf.geometry],
            out_shape=raster_shape,
            transform=transform,
            fill=0,
            dtype="uint8"
        )

        garnet_cmap = LinearSegmentedColormap.from_list(
            "garnet",
            ["#7b112c", "#7b112c"]
        )

        ax.imshow(
            np.ma.masked_where(mask_area == 0, mask_area),
            cmap=garnet_cmap,
            alpha=1.0
        )

        # Lekkie przybliżenie obszaru (bez dużego zoomu)
        rows, cols = np.where(mask_area == 1)
        if len(rows) > 0:
            pad = 30
            ax.set_xlim(max(cols.min() - pad, 0), min(cols.max() + pad, raster_shape[1]))
            ax.set_ylim(min(rows.max() + pad, raster_shape[0]), max(rows.min() - pad, 0))

    # ----------------------------
    # Legenda
    # ----------------------------
    cbar = plt.colorbar(img, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("NDMI")

    ax.axis("off")
    st.pyplot(fig)

    # ----------------------------
    # Interpretacja NDMI
    # ----------------------------
    st.subheader("Interpretacja NDMI")

    st.markdown("""
- **NDMI < -0.24** – gleba jałowa  
- **-0.24 do -0.032** – bardzo niska wilgotność  
- **-0.032 do 0.032** – stres wodny  
- **0.032 do 0.24** – umiarkowana wilgotność  
- **> 0.24** – wysoka wilgotność roślinności
""")

else:
    st.info("Upload both B8 and B11 files.")
